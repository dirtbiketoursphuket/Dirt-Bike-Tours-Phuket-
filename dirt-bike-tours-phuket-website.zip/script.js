const menu=document.querySelector('.menu-toggle');
const header=document.querySelector('.site-header');
menu?.addEventListener('click',()=>header.classList.toggle('open'));
document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>header.classList.remove('open')));
document.getElementById('year').textContent=new Date().getFullYear();

const WHATSAPP_NUMBER='66900000000'; // CHANGE THIS to your real WhatsApp number, digits only, no + or spaces.
const whatsappBase=`https://wa.me/${WHATSAPP_NUMBER}`;
document.getElementById('whatsappBtn').href=whatsappBase+'?text='+encodeURIComponent("Hi! I'd like to ask about Dirt Bike Tours Phuket.");

document.getElementById('bookForm').addEventListener('submit',function(e){
  e.preventDefault();
  const data=new FormData(this);
  const message=[
    "Hi! I'd like to book/ask about a dirt bike tour in Phuket.",
    `Name: ${data.get('name')}`,
    `Preferred date: ${data.get('date')}`,
    `Riders: ${data.get('riders')}`,
    `Bike: ${data.get('bike')}`,
    `Message: ${data.get('message')||'None'}`
  ].join('\n');
  window.open(whatsappBase+'?text='+encodeURIComponent(message),'_blank','noopener');
});
